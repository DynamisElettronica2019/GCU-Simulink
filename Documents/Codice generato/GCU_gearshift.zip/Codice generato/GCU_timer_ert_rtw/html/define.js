function CodeDefine() { 
this.def = new Array();
this.def["rt_OneStep"] = {file: "ert_main_c.html",line:39,type:"fcn"};
this.def["main"] = {file: "ert_main_c.html",line:76,type:"fcn"};
this.def["rtDW"] = {file: "GCU_timer_c.html",line:90,type:"var"};
this.def["rtU"] = {file: "GCU_timer_c.html",line:93,type:"var"};
this.def["rtY"] = {file: "GCU_timer_c.html",line:96,type:"var"};
this.def["rtM_"] = {file: "GCU_timer_c.html",line:99,type:"var"};
this.def["rtM"] = {file: "GCU_timer_c.html",line:100,type:"var"};
this.def["UnsetBlip"] = {file: "GCU_timer_c.html",line:355,type:"fcn"};
this.def["Gearmotor_release"] = {file: "GCU_timer_c.html",line:365,type:"fcn"};
this.def["Gearmotor_turnRight"] = {file: "GCU_timer_c.html",line:375,type:"fcn"};
this.def["Gearmotor_brake"] = {file: "GCU_timer_c.html",line:393,type:"fcn"};
this.def["EngineControl_Start"] = {file: "GCU_timer_c.html",line:411,type:"fcn"};
this.def["NEUTRAL_STATE"] = {file: "GCU_timer_c.html",line:422,type:"fcn"};
this.def["Gearshift_getTime"] = {file: "GCU_timer_c.html",line:455,type:"fcn"};
this.def["Clutch_setValue"] = {file: "GCU_timer_c.html",line:519,type:"fcn"};
this.def["GEARSHIFT"] = {file: "GCU_timer_c.html",line:538,type:"fcn"};
this.def["checkShift"] = {file: "GCU_timer_c.html",line:860,type:"fcn"};
this.def["getAacParam"] = {file: "GCU_timer_c.html",line:936,type:"fcn"};
this.def["rt_roundd_snf"] = {file: "GCU_timer_c.html",line:949,type:"fcn"};
this.def["aacCheckShift"] = {file: "GCU_timer_c.html",line:968,type:"fcn"};
this.def["ACTIVE"] = {file: "GCU_timer_c.html",line:1010,type:"fcn"};
this.def["checkClutch"] = {file: "GCU_timer_c.html",line:1260,type:"fcn"};
this.def["GCU_timer_step"] = {file: "GCU_timer_c.html",line:1274,type:"fcn"};
this.def["GCU_timer_initialize"] = {file: "GCU_timer_c.html",line:1510,type:"fcn"};
this.def["RT_MODEL"] = {file: "GCU_timer_h.html",line:51,type:"type"};
this.def["timings"] = {file: "GCU_timer_h.html",line:80,type:"type"};
this.def["aac_params"] = {file: "GCU_timer_h.html",line:99,type:"type"};
this.def["aac_values"] = {file: "GCU_timer_h.html",line:110,type:"type"};
this.def["DW_UnsetBlip"] = {file: "GCU_timer_h.html",line:117,type:"type"};
this.def["DW_Gearmotor_turnRight"] = {file: "GCU_timer_h.html",line:124,type:"type"};
this.def["DW_Gearmotor_brake"] = {file: "GCU_timer_h.html",line:131,type:"type"};
this.def["DW_EngineControl_Start"] = {file: "GCU_timer_h.html",line:136,type:"type"};
this.def["DW"] = {file: "GCU_timer_h.html",line:193,type:"type"};
this.def["ExtU"] = {file: "GCU_timer_h.html",line:203,type:"type"};
this.def["ExtY"] = {file: "GCU_timer_h.html",line:216,type:"type"};
this.def["int8_T"] = {file: "rtwtypes_h.html",line:53,type:"type"};
this.def["uint8_T"] = {file: "rtwtypes_h.html",line:54,type:"type"};
this.def["int16_T"] = {file: "rtwtypes_h.html",line:55,type:"type"};
this.def["uint16_T"] = {file: "rtwtypes_h.html",line:56,type:"type"};
this.def["int32_T"] = {file: "rtwtypes_h.html",line:57,type:"type"};
this.def["uint32_T"] = {file: "rtwtypes_h.html",line:58,type:"type"};
this.def["int64_T"] = {file: "rtwtypes_h.html",line:59,type:"type"};
this.def["uint64_T"] = {file: "rtwtypes_h.html",line:60,type:"type"};
this.def["real32_T"] = {file: "rtwtypes_h.html",line:61,type:"type"};
this.def["real64_T"] = {file: "rtwtypes_h.html",line:62,type:"type"};
this.def["real_T"] = {file: "rtwtypes_h.html",line:68,type:"type"};
this.def["time_T"] = {file: "rtwtypes_h.html",line:69,type:"type"};
this.def["boolean_T"] = {file: "rtwtypes_h.html",line:70,type:"type"};
this.def["int_T"] = {file: "rtwtypes_h.html",line:71,type:"type"};
this.def["uint_T"] = {file: "rtwtypes_h.html",line:72,type:"type"};
this.def["ulong_T"] = {file: "rtwtypes_h.html",line:73,type:"type"};
this.def["ulonglong_T"] = {file: "rtwtypes_h.html",line:74,type:"type"};
this.def["char_T"] = {file: "rtwtypes_h.html",line:75,type:"type"};
this.def["uchar_T"] = {file: "rtwtypes_h.html",line:76,type:"type"};
this.def["byte_T"] = {file: "rtwtypes_h.html",line:77,type:"type"};
this.def["pointer_T"] = {file: "rtwtypes_h.html",line:98,type:"type"};
}
CodeDefine.instance = new CodeDefine();
var testHarnessInfo = {OwnerFileName: "", HarnessOwner: "", HarnessName: "", IsTestHarness: "0"};
var relPathToBuildDir = "../ert_main.c";
var fileSep = "\\";
var isPC = true;
function Html2SrcLink() {
	this.html2SrcPath = new Array;
	this.html2Root = new Array;
	this.html2SrcPath["ert_main_c.html"] = "../ert_main.c";
	this.html2Root["ert_main_c.html"] = "ert_main_c.html";
	this.html2SrcPath["GCU_timer_c.html"] = "../GCU_timer.c";
	this.html2Root["GCU_timer_c.html"] = "GCU_timer_c.html";
	this.html2SrcPath["GCU_timer_h.html"] = "../GCU_timer.h";
	this.html2Root["GCU_timer_h.html"] = "GCU_timer_h.html";
	this.html2SrcPath["rtwtypes_h.html"] = "../rtwtypes.h";
	this.html2Root["rtwtypes_h.html"] = "rtwtypes_h.html";
	this.getLink2Src = function (htmlFileName) {
		 if (this.html2SrcPath[htmlFileName])
			 return this.html2SrcPath[htmlFileName];
		 else
			 return null;
	}
	this.getLinkFromRoot = function (htmlFileName) {
		 if (this.html2Root[htmlFileName])
			 return this.html2Root[htmlFileName];
		 else
			 return null;
	}
}
Html2SrcLink.instance = new Html2SrcLink();
var fileList = [
"ert_main_c.html","GCU_timer_c.html","GCU_timer_h.html","rtwtypes_h.html"];
