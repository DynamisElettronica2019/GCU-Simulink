function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.var["rtDW"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	size: 126};
	 this.metricsArray.var["rtM_"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	size: 277};
	 this.metricsArray.var["rtU"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	size: 18};
	 this.metricsArray.var["rtY"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	size: 12};
	 this.metricsArray.fcn["ClutchMotor_setPosition_Outputs_wrapper"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Efi_setCut_Outputs_wrapper"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Efi_setRPMLimiter_Outputs_wrapper"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Efi_unsetBlip_Outputs_wrapper"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Efi_unsetCut_Outputs_wrapper"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Efi_unsetRPMLimiter_Outputs_wrapper"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["EngineControl_start_Outputs_wrapper"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["EngineControl_stop_Outputs_wrapper"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["GCU_timer.c:ACTIVE"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 34,
	stackTotal: 42};
	 this.metricsArray.fcn["GCU_timer.c:Clutch_setValue"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["GCU_timer.c:EngineControl_Start"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["GCU_timer.c:GEARSHIFT"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 4};
	 this.metricsArray.fcn["GCU_timer.c:Gearmotor_brake"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["GCU_timer.c:Gearmotor_release"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["GCU_timer.c:Gearmotor_turnRight"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["GCU_timer.c:Gearshift_getTime"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["GCU_timer.c:NEUTRAL_STATE"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["GCU_timer.c:UnsetBlip"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["GCU_timer.c:aacCheckShift"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 4,
	stackTotal: 8};
	 this.metricsArray.fcn["GCU_timer.c:checkClutch"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["GCU_timer.c:checkShift"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 4,
	stackTotal: 8};
	 this.metricsArray.fcn["GCU_timer.c:getAacParam"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["GCU_timer_initialize"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["GCU_timer_step"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 4,
	stackTotal: 46};
	 this.metricsArray.fcn["GearMotor_brake_Outputs_wrapper"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["GearMotor_release_Outputs_wrapper"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["GearMotor_turnLeft_Outputs_wrapper"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["GearMotor_turnRight_Outputs_wrapper"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["ceil"] = {file: "C:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fabs"] = {file: "C:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["floor"] = {file: "C:\\Program Files\\MATLAB\\R2018a\\sys\\lcc\\include\\math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rt_roundd_snf"] = {file: "C:\\Users\\SIMONE\\Documents\\Programmi per GCU\\GCU model\\Codice generato\\GCU_timer_ert_rtw\\GCU_timer.c",
	stack: 8,
	stackTotal: 8};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data; }; 
	 this.codeMetricsSummary = '<a href="GCU_timer_metrics.html">Global Memory: 433(bytes) Maximum Stack: 34(bytes)</a>';
	}
CodeMetrics.instance = new CodeMetrics();
