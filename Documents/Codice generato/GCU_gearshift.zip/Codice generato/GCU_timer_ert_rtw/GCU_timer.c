/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: GCU_timer.c
 *
 * Code generated for Simulink model 'GCU_timer'.
 *
 * Model version                  : 1.127
 * Simulink Coder version         : 8.14 (R2018a) 06-Feb-2018
 * C/C++ source code generated on : Sat Feb 16 15:38:47 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#include "GCU_timer.h"

/* Named constants for Chart: '<Root>/GCULogic' */
#define AAC_WORK_RATE_ms               ((uint16_T)25U)
#define CALL_EVENT                     (-1)
#define GEAR_COMMAND_DOWN              ((uint16_T)200U)
#define GEAR_COMMAND_NEUTRAL_DOWN      ((uint16_T)100U)
#define GEAR_COMMAND_NEUTRAL_UP        ((uint16_T)50U)
#define GEAR_COMMAND_UP                ((uint16_T)400U)
#define IN_AAC                         ((uint8_T)1U)
#define IN_ACTIVE                      ((uint8_T)1U)
#define IN_ChangeClutch                ((uint8_T)1U)
#define IN_CutOff                      ((uint8_T)1U)
#define IN_DOWNSHIFTING                ((uint8_T)1U)
#define IN_DOWN_BRAKE                  ((uint8_T)1U)
#define IN_DOWN_END                    ((uint8_T)2U)
#define IN_DOWN_PUSH                   ((uint8_T)2U)
#define IN_DOWN_REBOUND                ((uint8_T)3U)
#define IN_DOWN_START                  ((uint8_T)4U)
#define IN_Default                     ((uint8_T)1U)
#define IN_Default_n                   ((uint8_T)2U)
#define IN_IDLE                        ((uint8_T)3U)
#define IN_INIT                        ((uint8_T)2U)
#define IN_INIT_f                      ((uint8_T)4U)
#define IN_NEUTRAL                     ((uint8_T)1U)
#define IN_NORMAL                      ((uint8_T)3U)
#define IN_NO_ACTIVE_CHILD             ((uint8_T)0U)
#define IN_NO_NEUTRAL                  ((uint8_T)2U)
#define IN_READY                       ((uint8_T)1U)
#define IN_RELEASING                   ((uint8_T)2U)
#define IN_RUNNING                     ((uint8_T)3U)
#define IN_SET_NEUTRAL                 ((uint8_T)3U)
#define IN_START                       ((uint8_T)4U)
#define IN_START_RELEASE               ((uint8_T)5U)
#define IN_START_b                     ((uint8_T)1U)
#define IN_STOP                        ((uint8_T)2U)
#define IN_STOPPING                    ((uint8_T)2U)
#define IN_SettingNeutral              ((uint8_T)2U)
#define IN_SettingNeutral_j            ((uint8_T)3U)
#define IN_UNSET_NEUTRAL               ((uint8_T)4U)
#define IN_UPSHIFTING                  ((uint8_T)5U)
#define IN_UP_BRAKE                    ((uint8_T)1U)
#define IN_UP_END                      ((uint8_T)6U)
#define IN_UP_PUSH                     ((uint8_T)2U)
#define IN_UP_REBOUND                  ((uint8_T)3U)
#define IN_UP_START                    ((uint8_T)4U)
#define IN_WAIT                        ((uint8_T)3U)
#define RELEASE_AAC_COM                ((uint16_T)2U)
#define START_AAC_COM                  ((uint16_T)1U)
#define STOP_AAC_COM                   ((uint16_T)0U)
#define event_GearshiftDown            (0)
#define event_GearshiftSetNeutral      (1)
#define event_GearshiftUp              (2)

/* Private macros used by the generated code to access rtModel */
#ifndef rtmIsMajorTimeStep
# define rtmIsMajorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
# define rtmIsMinorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmSetTPtr
# define rtmSetTPtr(rtm, val)          ((rtm)->Timing.t = (val))
#endif

/* Block signals and states (default storage) */
DW rtDW;

/* External inputs (root inport signals with default storage) */
ExtU rtU;

/* External outputs (root outports fed by signals with default storage) */
ExtY rtY;

/* Real-time model */
RT_MODEL rtM_;
RT_MODEL *const rtM = &rtM_;

#ifdef __cplusplus

extern "C" {

#endif

  extern void ClutchMotor_init_Start_wrapper(void);
  extern void ClutchMotor_init_Outputs_wrapper(void);
  extern void ClutchMotor_init_Terminate_wrapper(void);

#ifdef __cplusplus

}
#endif

#ifdef __cplusplus

extern "C" {

#endif

  extern void ClutchMotor_setPosition_Start_wrapper(void);
  extern void ClutchMotor_setPosition_Outputs_wrapper(const uint8_T *percentage);
  extern void ClutchMotor_setPosition_Terminate_wrapper(void);

#ifdef __cplusplus

}
#endif

#ifdef __cplusplus

extern "C" {

#endif

  extern void Efi_init_Start_wrapper(void);
  extern void Efi_init_Outputs_wrapper(void);
  extern void Efi_init_Terminate_wrapper(void);

#ifdef __cplusplus

}
#endif

#ifdef __cplusplus

extern "C" {

#endif

  extern void Efi_setCut_Start_wrapper(void);
  extern void Efi_setCut_Outputs_wrapper(uint8_T *upCut_pin);
  extern void Efi_setCut_Terminate_wrapper(void);

#ifdef __cplusplus

}
#endif

#ifdef __cplusplus

extern "C" {

#endif

  extern void Efi_unsetCut_Start_wrapper(void);
  extern void Efi_unsetCut_Outputs_wrapper(uint8_T *upCut_pin);
  extern void Efi_unsetCut_Terminate_wrapper(void);

#ifdef __cplusplus

}
#endif

#ifdef __cplusplus

extern "C" {

#endif

  extern void Efi_setBlip_Start_wrapper(void);
  extern void Efi_setBlip_Outputs_wrapper(uint8_T *downCut_pin);
  extern void Efi_setBlip_Terminate_wrapper(void);

#ifdef __cplusplus

}
#endif

#ifdef __cplusplus

extern "C" {

#endif

  extern void Efi_unsetBlip_Start_wrapper(void);
  extern void Efi_unsetBlip_Outputs_wrapper(uint8_T *downCut_pin);
  extern void Efi_unsetBlip_Terminate_wrapper(void);

#ifdef __cplusplus

}
#endif

#ifdef __cplusplus

extern "C" {

#endif

  extern void Efi_setRPMLimiter_Start_wrapper(void);
  extern void Efi_setRPMLimiter_Outputs_wrapper(uint8_T *rpmLimiter_pin);
  extern void Efi_setRPMLimiter_Terminate_wrapper(void);

#ifdef __cplusplus

}
#endif

#ifdef __cplusplus

extern "C" {

#endif

  extern void Efi_unsetRPMLimiter_Start_wrapper(void);
  extern void Efi_unsetRPMLimiter_Outputs_wrapper(uint8_T *rpmLimiter_pin);
  extern void Efi_unsetRPMLimiter_Terminate_wrapper(void);

#ifdef __cplusplus

}
#endif

#ifdef __cplusplus

extern "C" {

#endif

  extern void GearMotor_release_Start_wrapper(void);
  extern void GearMotor_release_Outputs_wrapper(uint8_T *GearMotor_H);
  extern void GearMotor_release_Terminate_wrapper(void);

#ifdef __cplusplus

}
#endif

#ifdef __cplusplus

extern "C" {

#endif

  extern void GearMotor_turnRight_Start_wrapper(void);
  extern void GearMotor_turnRight_Outputs_wrapper(uint8_T *GearMotor_In1,
    uint8_T *GearMotor_In2,
    uint8_T *GearMotor_H);
  extern void GearMotor_turnRight_Terminate_wrapper(void);

#ifdef __cplusplus

}
#endif

#ifdef __cplusplus

extern "C" {

#endif

  extern void GearMotor_turnLeft_Start_wrapper(void);
  extern void GearMotor_turnLeft_Outputs_wrapper(uint8_T *GearMotor_In1,
    uint8_T *GearMotor_In2,
    uint8_T *GearMotor_H);
  extern void GearMotor_turnLeft_Terminate_wrapper(void);

#ifdef __cplusplus

}
#endif

#ifdef __cplusplus

extern "C" {

#endif

  extern void GearMotor_brake_Start_wrapper(void);
  extern void GearMotor_brake_Outputs_wrapper(uint8_T *GearMotor_In1,
    uint8_T *GearMotor_In2,
    uint8_T *GearMotor_H);
  extern void GearMotor_brake_Terminate_wrapper(void);

#ifdef __cplusplus

}
#endif

#ifdef __cplusplus

extern "C" {

#endif

  extern void EngineControl_start_Start_wrapper(void);
  extern void EngineControl_start_Outputs_wrapper(uint8_T *engine_starter);
  extern void EngineControl_start_Terminate_wrapper(void);

#ifdef __cplusplus

}
#endif

#ifdef __cplusplus

extern "C" {

#endif

  extern void EngineControl_stop_Start_wrapper(void);
  extern void EngineControl_stop_Outputs_wrapper(uint8_T *engine_starter);
  extern void EngineControl_stop_Terminate_wrapper(void);

#ifdef __cplusplus

}
#endif

extern real_T rt_roundd_snf(real_T u);
static void UnsetBlip(uint8_T *rty_downCut_pin, DW_UnsetBlip *localDW);
static void Gearmotor_turnRight(uint8_T *rty_Pin_In1, uint8_T *rty_Pin_In2,
  uint8_T *rty_Pin_H, DW_Gearmotor_turnRight *localDW);
static void Gearmotor_brake(uint8_T *rty_Pin_In1, uint8_T *rty_Pin_In2, uint8_T *
  rty_Pin_H, DW_Gearmotor_brake *localDW);
static void EngineControl_Start(uint8_T *rty_engine_starter,
  DW_EngineControl_Start *localDW);
static void Gearmotor_release(void);

/* Forward declaration for local functions */
static void NEUTRAL_STATE(void);
static int32_T Gearshift_getTime(void);
static void Clutch_setValue(uint8_T setValue);
static void GEARSHIFT(void);
static void checkShift(void);
static int32_T getAacParam(aac_params b_index);
static void aacCheckShift(void);
static void ACTIVE(void);
static void checkClutch(void);

/* Output and update for function-call system: '<S2>/UnsetBlip' */
static void UnsetBlip(uint8_T *rty_downCut_pin, DW_UnsetBlip *localDW)
{
  /* S-Function (Efi_unsetBlip): '<S15>/Efi UnSetBlip' */
  Efi_unsetBlip_Outputs_wrapper(&localDW->EfiUnSetBlip);

  /* SignalConversion: '<S15>/OutportBufferFordownCut_pin' */
  *rty_downCut_pin = localDW->EfiUnSetBlip;
}

/* Output and update for function-call system: '<S5>/Gearmotor_release' */
static void Gearmotor_release(void)
{
  /* S-Function (GearMotor_release): '<S21>/GearMotor Release' */
  GearMotor_release_Outputs_wrapper(&rtDW.GearMotorRelease);

  /* SignalConversion: '<S21>/OutportBufferForPin H' */
  rtDW.Pin_H = rtDW.GearMotorRelease;
}

/* Output and update for function-call system: '<S5>/Gearmotor_turnRight' */
static void Gearmotor_turnRight(uint8_T *rty_Pin_In1, uint8_T *rty_Pin_In2,
  uint8_T *rty_Pin_H, DW_Gearmotor_turnRight *localDW)
{
  /* S-Function (GearMotor_turnRight): '<S23>/GearMotor Turn Right' */
  GearMotor_turnRight_Outputs_wrapper(&localDW->GearMotorTurnRight_o1,
    &localDW->GearMotorTurnRight_o2, &localDW->GearMotorTurnRight_o3);

  /* SignalConversion: '<S23>/OutportBufferForPin_H' */
  *rty_Pin_H = localDW->GearMotorTurnRight_o3;

  /* SignalConversion: '<S23>/OutportBufferForPin_In1' */
  *rty_Pin_In1 = localDW->GearMotorTurnRight_o1;

  /* SignalConversion: '<S23>/OutportBufferForPin_In2' */
  *rty_Pin_In2 = localDW->GearMotorTurnRight_o2;
}

/* Output and update for function-call system: '<S5>/Gearmotor_brake' */
static void Gearmotor_brake(uint8_T *rty_Pin_In1, uint8_T *rty_Pin_In2, uint8_T *
  rty_Pin_H, DW_Gearmotor_brake *localDW)
{
  /* S-Function (GearMotor_brake): '<S20>/GearMotor Brake' */
  GearMotor_brake_Outputs_wrapper(&localDW->GearMotorBrake_o1,
    &localDW->GearMotorBrake_o2, &localDW->GearMotorBrake_o3);

  /* SignalConversion: '<S20>/OutportBufferForPin_H' */
  *rty_Pin_H = localDW->GearMotorBrake_o3;

  /* SignalConversion: '<S20>/OutportBufferForPin_In1' */
  *rty_Pin_In1 = localDW->GearMotorBrake_o1;

  /* SignalConversion: '<S20>/OutportBufferForPin_In2' */
  *rty_Pin_In2 = localDW->GearMotorBrake_o2;
}

/* Output and update for function-call system: '<S3>/EngineControl_Start' */
static void EngineControl_Start(uint8_T *rty_engine_starter,
  DW_EngineControl_Start *localDW)
{
  /* S-Function (EngineControl_start): '<S18>/EngineControl Start' */
  EngineControl_start_Outputs_wrapper(&localDW->EngineControlStart);

  /* SignalConversion: '<S18>/OutportBufferForengine_starter' */
  *rty_engine_starter = localDW->EngineControlStart;
}

/* Function for Chart: '<Root>/GCULogic' */
static void NEUTRAL_STATE(void)
{
  switch (rtDW.is_NEUTRAL_STATE) {
   case IN_NEUTRAL:
    if ((rtDW.sfEvent == event_GearshiftUp) || (rtDW.sfEvent ==
         event_GearshiftDown)) {
      rtDW.is_NEUTRAL_STATE = IN_UNSET_NEUTRAL;
    }
    break;

   case IN_NO_NEUTRAL:
    if (rtDW.sfEvent == event_GearshiftSetNeutral) {
      rtDW.is_NEUTRAL_STATE = IN_SET_NEUTRAL;
    }
    break;

   case IN_SET_NEUTRAL:
    if ((rtDW.is_GEARSHIFT == IN_DOWN_END) || (rtDW.is_GEARSHIFT == IN_UP_END))
    {
      rtDW.is_NEUTRAL_STATE = IN_NEUTRAL;
    }
    break;

   case IN_UNSET_NEUTRAL:
    if ((rtDW.is_GEARSHIFT == IN_DOWN_END) || (rtDW.is_GEARSHIFT == IN_UP_END))
    {
      rtDW.is_NEUTRAL_STATE = IN_NO_NEUTRAL;
    }
    break;
  }
}

/* Function for Chart: '<Root>/GCULogic' */
static int32_T Gearshift_getTime(void)
{
  int32_T time;
  if (rtDW.is_UPSHIFTING == IN_UP_START) {
    if (rtDW.is_NEUTRAL_STATE == IN_SET_NEUTRAL) {
      time = DEFAULT_NT_CLUTCH_DELAY;
    } else {
      time = DEFAULT_DELAY;
    }
  } else if (rtDW.is_UPSHIFTING == IN_UP_PUSH) {
    if (rtDW.is_NEUTRAL_STATE == IN_SET_NEUTRAL) {
      time = DEFAULT_NT_CLUTCH_DELAY;
    } else {
      /* Inport: '<Root>/currentGear' */
      switch (rtU.currentGear) {
       case 1:
        time = DEFAULT_UP_PUSH_1_2;
        break;

       case 2:
        time = DEFAULT_UP_PUSH_2_3;
        break;

       case 3:
        time = DEFAULT_UP_PUSH_3_4;
        break;

       case 4:
        time = DEFAULT_UP_PUSH_4_5;
        break;

       default:
        time = DEFAULT_UP_PUSH_2_3;
        break;
      }

      /* End of Inport: '<Root>/currentGear' */
    }
  } else if (rtDW.is_UPSHIFTING == IN_UP_REBOUND) {
    if (rtDW.is_NEUTRAL_STATE == IN_SET_NEUTRAL) {
      time = DEFAULT_NT_REBOUND_1_N;
    } else {
      time = DEFAULT_UP_REBOUND;
    }
  } else if (rtDW.is_UPSHIFTING == IN_UP_BRAKE) {
    if (rtDW.is_NEUTRAL_STATE == IN_SET_NEUTRAL) {
      time = DEFAULT_NT_BRAKE_1_N;
    } else {
      time = DEFAULT_UP_BRAKE;
    }
  } else if (rtDW.is_DOWNSHIFTING == IN_DOWN_START) {
    time = DEFAULT_CLUTCH;
  } else if (rtDW.is_DOWNSHIFTING == IN_DOWN_PUSH) {
    time = DEFAULT_DN_PUSH;
  } else if (rtDW.is_DOWNSHIFTING == IN_DOWN_REBOUND) {
    time = DEFAULT_DN_REBOUND;
  } else {
    time = DEFAULT_DN_BRAKE;
  }

  return time;
}

/* Function for Chart: '<Root>/GCULogic' */
static void Clutch_setValue(uint8_T setValue)
{
  /* Outport: '<Root>/clutchCurrVal' */
  rtY.clutchCurrVal = setValue;

  /* Outputs for Function Call SubSystem: '<S1>/ClutchMotor SetPosition ' */
  /* Sum: '<S10>/Minus' incorporates:
   *  Constant: '<S10>/Constant'
   *  Outport: '<Root>/clutchCurrVal'
   */
  rtDW.Minus = (uint8_T)(100 - rtY.clutchCurrVal);

  /* S-Function (ClutchMotor_setPosition): '<S10>/ClutchMotor SetPosition' */
  ClutchMotor_setPosition_Outputs_wrapper(&rtDW.Minus);

  /* End of Outputs for SubSystem: '<S1>/ClutchMotor SetPosition ' */
}

/* Function for Chart: '<Root>/GCULogic' */
static void GEARSHIFT(void)
{
  switch (rtDW.is_GEARSHIFT) {
   case IN_DOWNSHIFTING:
    switch (rtDW.is_DOWNSHIFTING) {
     case IN_DOWN_BRAKE:
      if (rtDW.ticksCounter == 0) {
        rtDW.is_DOWN_BRAKE = IN_NO_ACTIVE_CHILD;
        rtDW.is_DOWNSHIFTING = IN_NO_ACTIVE_CHILD;
        rtDW.is_GEARSHIFT = IN_NO_ACTIVE_CHILD;
        if (rtDW.is_GEARSHIFT != IN_DOWN_END) {
          rtDW.is_GEARSHIFT = IN_DOWN_END;

          /* Outputs for Function Call SubSystem: '<S5>/Gearmotor_release' */
          Gearmotor_release();

          /* End of Outputs for SubSystem: '<S5>/Gearmotor_release' */
        }
      } else if (rtDW.ticksCounter < -2147483647) {
        rtDW.ticksCounter = MIN_int32_T;
      } else {
        rtDW.ticksCounter--;
      }
      break;

     case IN_DOWN_PUSH:
      if (rtDW.ticksCounter == 0) {
        rtDW.is_DOWNSHIFTING = IN_NO_ACTIVE_CHILD;
        if (rtDW.is_DOWNSHIFTING != IN_DOWN_REBOUND) {
          rtDW.is_DOWNSHIFTING = IN_DOWN_REBOUND;
          rtDW.ticksCounter = Gearshift_getTime();

          /* Outputs for Function Call SubSystem: '<S5>/Gearmotor_release' */
          Gearmotor_release();

          /* End of Outputs for SubSystem: '<S5>/Gearmotor_release' */
        }
      } else if (rtDW.ticksCounter < -2147483647) {
        rtDW.ticksCounter = MIN_int32_T;
      } else {
        rtDW.ticksCounter--;
      }
      break;

     case IN_DOWN_REBOUND:
      if (rtDW.ticksCounter == 0) {
        rtDW.is_DOWNSHIFTING = IN_NO_ACTIVE_CHILD;
        if (rtDW.is_DOWNSHIFTING != IN_DOWN_BRAKE) {
          rtDW.is_DOWNSHIFTING = IN_DOWN_BRAKE;
          rtDW.ticksCounter = Gearshift_getTime();
        }

        /* Outport: '<Root>/clutchCurrVal' */
        if (rtY.clutchCurrVal < 81) {
          if (rtDW.is_DOWN_BRAKE != IN_ChangeClutch) {
            rtDW.is_DOWN_BRAKE = IN_ChangeClutch;
            Clutch_setValue(80);

            /* Outputs for Function Call SubSystem: '<S5>/Gearmotor_brake' */
            Gearmotor_brake(&rtDW.Pin_In1, &rtDW.Pin_In2, &rtDW.Pin_H,
                            &rtDW.Gearmotor_brake_g);

            /* End of Outputs for SubSystem: '<S5>/Gearmotor_brake' */
          }
        } else {
          if (rtDW.is_DOWN_BRAKE != IN_Default_n) {
            rtDW.is_DOWN_BRAKE = IN_Default_n;

            /* Outputs for Function Call SubSystem: '<S5>/Gearmotor_brake' */
            Gearmotor_brake(&rtDW.Pin_In1, &rtDW.Pin_In2, &rtDW.Pin_H,
                            &rtDW.Gearmotor_brake_g);

            /* End of Outputs for SubSystem: '<S5>/Gearmotor_brake' */
          }
        }
      } else if (rtDW.ticksCounter < -2147483647) {
        rtDW.ticksCounter = MIN_int32_T;
      } else {
        rtDW.ticksCounter--;
      }
      break;

     case IN_DOWN_START:
      if (rtDW.ticksCounter == 0) {
        rtDW.is_DOWN_START = IN_NO_ACTIVE_CHILD;
        rtDW.is_DOWNSHIFTING = IN_NO_ACTIVE_CHILD;
        if (rtDW.is_DOWNSHIFTING != IN_DOWN_PUSH) {
          rtDW.is_DOWNSHIFTING = IN_DOWN_PUSH;
          rtDW.ticksCounter = Gearshift_getTime();

          /* Outputs for Function Call SubSystem: '<S5>/Gearmotor_turnLeft' */
          /* S-Function (GearMotor_turnLeft): '<S22>/GearMotor Turn Left' */
          GearMotor_turnLeft_Outputs_wrapper(&rtDW.GearMotorTurnLeft_o1,
            &rtDW.GearMotorTurnLeft_o2, &rtDW.GearMotorTurnLeft_o3);

          /* SignalConversion: '<S22>/OutportBufferForPin_H' */
          rtDW.Pin_H = rtDW.GearMotorTurnLeft_o3;

          /* SignalConversion: '<S22>/OutportBufferForPin_In1' */
          rtDW.Pin_In1 = rtDW.GearMotorTurnLeft_o1;

          /* SignalConversion: '<S22>/OutportBufferForPin_In2' */
          rtDW.Pin_In2 = rtDW.GearMotorTurnLeft_o2;

          /* End of Outputs for SubSystem: '<S5>/Gearmotor_turnLeft' */
        }
      } else if (rtDW.ticksCounter < -2147483647) {
        rtDW.ticksCounter = MIN_int32_T;
      } else {
        rtDW.ticksCounter--;
      }
      break;
    }
    break;

   case IN_DOWN_END:
    rtDW.is_GEARSHIFT = IN_NO_ACTIVE_CHILD;
    if (rtDW.is_GEARSHIFT != IN_IDLE) {
      rtDW.is_GEARSHIFT = IN_IDLE;
    }
    break;

   case IN_IDLE:
    switch (rtDW.sfEvent) {
     case event_GearshiftUp:
      rtDW.is_GEARSHIFT = IN_UPSHIFTING;
      if (rtDW.is_UPSHIFTING != IN_UP_START) {
        rtDW.is_UPSHIFTING = IN_UP_START;
        rtDW.ticksCounter = Gearshift_getTime();
      }

      if (rtDW.is_NEUTRAL_STATE == IN_SET_NEUTRAL) {
        if (rtDW.is_UP_START != IN_SettingNeutral) {
          rtDW.is_UP_START = IN_SettingNeutral;
          Clutch_setValue(80);
        }
      } else {
        if (rtDW.is_UP_START != IN_Default) {
          rtDW.is_UP_START = IN_Default;

          /* Outputs for Function Call SubSystem: '<S2>/SetCut' */
          /* S-Function (Efi_setCut): '<S13>/Efi SetCut' */
          Efi_setCut_Outputs_wrapper(&rtDW.EfiSetCut);

          /* SignalConversion: '<S13>/OutportBufferFordownCut_pin' */
          rtDW.Merge1 = rtDW.EfiSetCut;

          /* End of Outputs for SubSystem: '<S2>/SetCut' */
        }
      }
      break;

     case event_GearshiftDown:
      rtDW.is_GEARSHIFT = IN_DOWNSHIFTING;
      if (rtDW.is_DOWNSHIFTING != IN_DOWN_START) {
        rtDW.is_DOWNSHIFTING = IN_DOWN_START;
        rtDW.ticksCounter = Gearshift_getTime();
      }

      /* Outport: '<Root>/clutchCurrVal' */
      if ((rtDW.is_NEUTRAL_STATE == IN_SET_NEUTRAL) && (rtY.clutchCurrVal <= 80))
      {
        if (rtDW.is_DOWN_START != IN_SettingNeutral_j) {
          rtDW.is_DOWN_START = IN_SettingNeutral_j;
          Clutch_setValue(80);
        }
      } else if ((!(rtDW.is_NEUTRAL_STATE == IN_UNSET_NEUTRAL)) &&
                 (rtY.clutchCurrVal <= 60)) {
        if (rtDW.is_DOWN_START != IN_ChangeClutch) {
          rtDW.is_DOWN_START = IN_ChangeClutch;
          Clutch_setValue(60);
        }
      } else {
        rtDW.is_DOWN_START = IN_Default_n;
      }
      break;
    }
    break;

   case IN_INIT_f:
    rtDW.is_GEARSHIFT = IN_NO_ACTIVE_CHILD;
    if (rtDW.is_GEARSHIFT != IN_IDLE) {
      rtDW.is_GEARSHIFT = IN_IDLE;
    }
    break;

   case IN_UPSHIFTING:
    switch (rtDW.is_UPSHIFTING) {
     case IN_UP_BRAKE:
      if (rtDW.ticksCounter == 0) {
        rtDW.is_UPSHIFTING = IN_NO_ACTIVE_CHILD;
        rtDW.is_GEARSHIFT = IN_NO_ACTIVE_CHILD;
        if (rtDW.is_GEARSHIFT != IN_UP_END) {
          rtDW.is_GEARSHIFT = IN_UP_END;

          /* Outputs for Function Call SubSystem: '<S5>/Gearmotor_release' */
          Gearmotor_release();

          /* End of Outputs for SubSystem: '<S5>/Gearmotor_release' */
        }
      } else if (rtDW.ticksCounter < -2147483647) {
        rtDW.ticksCounter = MIN_int32_T;
      } else {
        rtDW.ticksCounter--;
      }
      break;

     case IN_UP_PUSH:
      if (rtDW.ticksCounter == 0) {
        rtDW.is_UP_PUSH = IN_NO_ACTIVE_CHILD;
        rtDW.is_UPSHIFTING = IN_NO_ACTIVE_CHILD;
        if (rtDW.is_UPSHIFTING != IN_UP_REBOUND) {
          rtDW.is_UPSHIFTING = IN_UP_REBOUND;
          rtDW.ticksCounter = Gearshift_getTime();
        }

        if (rtDW.is_NEUTRAL_STATE == IN_SET_NEUTRAL) {
          if (rtDW.is_UP_REBOUND != IN_SettingNeutral) {
            rtDW.is_UP_REBOUND = IN_SettingNeutral;
            Clutch_setValue(0);

            /* Outputs for Function Call SubSystem: '<S5>/Gearmotor_release' */
            Gearmotor_release();

            /* End of Outputs for SubSystem: '<S5>/Gearmotor_release' */
          }
        } else {
          if (rtDW.is_UP_REBOUND != IN_Default) {
            rtDW.is_UP_REBOUND = IN_Default;

            /* Outputs for Function Call SubSystem: '<S5>/Gearmotor_release' */
            Gearmotor_release();

            /* End of Outputs for SubSystem: '<S5>/Gearmotor_release' */
          }
        }
      } else if (rtDW.ticksCounter < -2147483647) {
        rtDW.ticksCounter = MIN_int32_T;
      } else {
        rtDW.ticksCounter--;
      }
      break;

     case IN_UP_REBOUND:
      if (rtDW.ticksCounter == 0) {
        rtDW.is_UP_REBOUND = IN_NO_ACTIVE_CHILD;
        rtDW.is_UPSHIFTING = IN_NO_ACTIVE_CHILD;
        if (rtDW.is_UPSHIFTING != IN_UP_BRAKE) {
          rtDW.is_UPSHIFTING = IN_UP_BRAKE;
          rtDW.ticksCounter = Gearshift_getTime();

          /* Outputs for Function Call SubSystem: '<S5>/Gearmotor_brake' */
          Gearmotor_brake(&rtDW.Pin_In1, &rtDW.Pin_In2, &rtDW.Pin_H,
                          &rtDW.Gearmotor_brake_g);

          /* End of Outputs for SubSystem: '<S5>/Gearmotor_brake' */
        }
      } else if (rtDW.ticksCounter < -2147483647) {
        rtDW.ticksCounter = MIN_int32_T;
      } else {
        rtDW.ticksCounter--;
      }
      break;

     case IN_UP_START:
      if (rtDW.ticksCounter == 0) {
        rtDW.is_UP_START = IN_NO_ACTIVE_CHILD;
        rtDW.is_UPSHIFTING = IN_NO_ACTIVE_CHILD;
        if (rtDW.is_UPSHIFTING != IN_UP_PUSH) {
          rtDW.is_UPSHIFTING = IN_UP_PUSH;
          rtDW.ticksCounter = Gearshift_getTime();
        }

        if (!(rtDW.is_NEUTRAL_STATE == IN_SET_NEUTRAL)) {
          if (rtDW.is_UP_PUSH != IN_CutOff) {
            rtDW.is_UP_PUSH = IN_CutOff;

            /* Outputs for Function Call SubSystem: '<S2>/UnsetCut' */
            /* S-Function (Efi_unsetCut): '<S16>/Efi UnSetCut' */
            Efi_unsetCut_Outputs_wrapper(&rtDW.EfiUnSetCut);

            /* SignalConversion: '<S16>/OutportBufferFordownCut_pin' */
            rtDW.Merge1 = rtDW.EfiUnSetCut;

            /* End of Outputs for SubSystem: '<S2>/UnsetCut' */

            /* Outputs for Function Call SubSystem: '<S5>/Gearmotor_turnRight' */
            Gearmotor_turnRight(&rtDW.Pin_In1, &rtDW.Pin_In2, &rtDW.Pin_H,
                                &rtDW.Gearmotor_turnRight_p);

            /* End of Outputs for SubSystem: '<S5>/Gearmotor_turnRight' */
          }
        } else {
          if (rtDW.is_UP_PUSH != IN_Default_n) {
            rtDW.is_UP_PUSH = IN_Default_n;

            /* Outputs for Function Call SubSystem: '<S5>/Gearmotor_turnRight' */
            Gearmotor_turnRight(&rtDW.Pin_In1, &rtDW.Pin_In2, &rtDW.Pin_H,
                                &rtDW.Gearmotor_turnRight_p);

            /* End of Outputs for SubSystem: '<S5>/Gearmotor_turnRight' */
          }
        }
      } else if (rtDW.ticksCounter < -2147483647) {
        rtDW.ticksCounter = MIN_int32_T;
      } else {
        rtDW.ticksCounter--;
      }
      break;
    }
    break;

   case IN_UP_END:
    rtDW.is_GEARSHIFT = IN_NO_ACTIVE_CHILD;
    if (rtDW.is_GEARSHIFT != IN_IDLE) {
      rtDW.is_GEARSHIFT = IN_IDLE;
    }
    break;
  }
}

/* Function for Chart: '<Root>/GCULogic' */
static void checkShift(void)
{
  int32_T b_previousEvent;

  /* Inport: '<Root>/shiftCom' */
  if (rtU.shiftCom[0] != rtDW.lastShiftCom) {
    rtDW.lastShiftCom = rtU.shiftCom[0];
    if (rtU.shiftCom[1] == GEAR_COMMAND_UP) {
      b_previousEvent = rtDW.sfEvent;
      rtDW.sfEvent = event_GearshiftUp;
      if (rtDW.is_active_NEUTRAL_STATE != 0U) {
        NEUTRAL_STATE();
      }

      rtDW.sfEvent = b_previousEvent;
      b_previousEvent = rtDW.sfEvent;
      rtDW.sfEvent = event_GearshiftUp;
      if (rtDW.is_active_GEARSHIFT != 0U) {
        GEARSHIFT();
      }

      rtDW.sfEvent = b_previousEvent;
    } else if (rtU.shiftCom[1] == GEAR_COMMAND_DOWN) {
      b_previousEvent = rtDW.sfEvent;
      rtDW.sfEvent = event_GearshiftDown;
      if (rtDW.is_active_NEUTRAL_STATE != 0U) {
        NEUTRAL_STATE();
      }

      rtDW.sfEvent = b_previousEvent;
      b_previousEvent = rtDW.sfEvent;
      rtDW.sfEvent = event_GearshiftDown;
      if (rtDW.is_active_GEARSHIFT != 0U) {
        GEARSHIFT();
      }

      rtDW.sfEvent = b_previousEvent;
    } else if (rtU.shiftCom[1] == GEAR_COMMAND_NEUTRAL_UP) {
      b_previousEvent = rtDW.sfEvent;
      rtDW.sfEvent = event_GearshiftSetNeutral;
      if (rtDW.is_active_NEUTRAL_STATE != 0U) {
        NEUTRAL_STATE();
      }

      rtDW.sfEvent = b_previousEvent;
      b_previousEvent = rtDW.sfEvent;
      rtDW.sfEvent = event_GearshiftUp;
      if (rtDW.is_active_GEARSHIFT != 0U) {
        GEARSHIFT();
      }

      rtDW.sfEvent = b_previousEvent;
    } else {
      if (rtU.shiftCom[1] == GEAR_COMMAND_NEUTRAL_DOWN) {
        b_previousEvent = rtDW.sfEvent;
        rtDW.sfEvent = event_GearshiftSetNeutral;
        if (rtDW.is_active_NEUTRAL_STATE != 0U) {
          NEUTRAL_STATE();
        }

        rtDW.sfEvent = b_previousEvent;
        b_previousEvent = rtDW.sfEvent;
        rtDW.sfEvent = event_GearshiftDown;
        if (rtDW.is_active_GEARSHIFT != 0U) {
          GEARSHIFT();
        }

        rtDW.sfEvent = b_previousEvent;
      }
    }
  }

  /* End of Inport: '<Root>/shiftCom' */
}

/* Function for Chart: '<Root>/GCULogic' */
static int32_T getAacParam(aac_params b_index)
{
  int32_T q0;
  q0 = b_index;
  if (q0 > 2147483646) {
    q0 = MAX_int32_T;
  } else {
    q0++;
  }

  return rtDW.aac_parameters[q0 - 1];
}

real_T rt_roundd_snf(real_T u)
{
  real_T y;
  if (fabs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

/* Function for Chart: '<Root>/GCULogic' */
static void aacCheckShift(void)
{
  int32_T b_previousEvent;

  /* Inport: '<Root>/currentGear' */
  if (rtDW.lastShift == rtU.currentGear) {
    b_previousEvent = (int32_T)((uint32_T)RPM_LIMIT_1_2 + rtU.currentGear);
    if ((uint32_T)b_previousEvent > 255U) {
      b_previousEvent = 255;
    }

    /* Inport: '<Root>/aac_externValues' */
    if (rtU.aac_externValues[0] >= rtDW.aac_parameters[b_previousEvent - 1]) {
      b_previousEvent = (int32_T)((uint32_T)SPEED_LIMIT_1_2 + rtU.currentGear);
      if ((uint32_T)b_previousEvent > 255U) {
        b_previousEvent = 255;
      }

      if (rtU.aac_externValues[1] >= rtDW.aac_parameters[b_previousEvent - 1]) {
        b_previousEvent = rtDW.sfEvent;
        rtDW.sfEvent = event_GearshiftUp;
        if (rtDW.is_active_GEARSHIFT != 0U) {
          GEARSHIFT();
        }

        rtDW.sfEvent = b_previousEvent;
        b_previousEvent = (int32_T)(rtDW.lastShift + 1U);
        if ((uint32_T)b_previousEvent > 255U) {
          b_previousEvent = 255;
        }

        rtDW.lastShift = (uint8_T)b_previousEvent;
      }
    }

    /* End of Inport: '<Root>/aac_externValues' */
  }

  /* End of Inport: '<Root>/currentGear' */
}

/* Function for Chart: '<Root>/GCULogic' */
static void ACTIVE(void)
{
  int32_T A;
  uint32_T q;
  boolean_T c_sf_internal_predicateOutput;
  int32_T q1;
  int64_T tmp;
  real_T tmp_0;
  uint32_T qY;
  uint8_T tmp_1;

  /* Inport: '<Root>/aacCom' */
  if ((rtU.aacCom[0] != rtDW.lastAacCom) && (rtU.aacCom[1] == STOP_AAC_COM)) {
    rtDW.lastAacCom = rtU.aacCom[0];
    rtDW.is_ACTIVE = IN_NO_ACTIVE_CHILD;
    rtDW.is_AAC = IN_NO_ACTIVE_CHILD;
    if (rtDW.is_AAC != IN_STOPPING) {
      rtDW.is_AAC = IN_STOPPING;

      /* Outputs for Function Call SubSystem: '<S2>/UnsetBlip' */
      UnsetBlip(&rtDW.Merge, &rtDW.UnsetBlip_e);

      /* End of Outputs for SubSystem: '<S2>/UnsetBlip' */
    }
  } else {
    switch (rtDW.is_ACTIVE) {
     case IN_READY:
      if (rtDW.aacCounter <= 1) {
        if ((rtU.aacCom[0] != rtDW.lastAacCom) && (rtU.aacCom[1] ==
             RELEASE_AAC_COM)) {
          rtDW.lastAacCom = rtU.aacCom[0];
          rtDW.is_ACTIVE = IN_NO_ACTIVE_CHILD;
          if (rtDW.is_ACTIVE != IN_START_RELEASE) {
            rtDW.is_ACTIVE = IN_START_RELEASE;
            rtDW.aac_clutchValue = getAacParam(RAMP_START);
            tmp_0 = rt_roundd_snf(rtDW.aac_clutchValue);
            if (tmp_0 < 256.0) {
              if (tmp_0 >= 0.0) {
                tmp_1 = (uint8_T)tmp_0;
              } else {
                tmp_1 = 0U;
              }
            } else {
              tmp_1 = MAX_uint8_T;
            }

            Clutch_setValue(tmp_1);
            A = getAacParam(RAMP_TIME);
            if (A >= 0) {
              qY = (uint32_T)A;
            } else if (A == MIN_int32_T) {
              qY = 2147483648U;
            } else {
              qY = (uint32_T)-A;
            }

            q = qY / 25U;
            qY -= q * 25U;
            if ((qY > 0U) && (qY >= 13U)) {
              q++;
            }

            rtDW.aac_dtRelease = (int32_T)q;
            if (A < 0) {
              rtDW.aac_dtRelease = -rtDW.aac_dtRelease;
            }

            A = getAacParam(RAMP_START);
            q1 = getAacParam(RAMP_END);
            if ((A >= 0) && (q1 < A - MAX_int32_T)) {
              A = MAX_int32_T;
            } else if ((A < 0) && (q1 > A - MIN_int32_T)) {
              A = MIN_int32_T;
            } else {
              A -= q1;
            }

            tmp = (int64_T)A * AAC_WORK_RATE_ms;
            if (tmp > 2147483647LL) {
              tmp = 2147483647LL;
            } else {
              if (tmp < -2147483648LL) {
                tmp = -2147483648LL;
              }
            }

            A = getAacParam(RAMP_TIME);
            rtDW.aac_clutchStep = (real_T)(int32_T)tmp / (real_T)A;
            rtDW.aacCounter = AAC_WORK_RATE_ms;
          }
        } else {
          rtDW.is_ACTIVE = IN_NO_ACTIVE_CHILD;
          if (rtDW.is_ACTIVE != IN_READY) {
            rtDW.is_ACTIVE = IN_READY;
            rtDW.aacCounter = AAC_WORK_RATE_ms;
            Clutch_setValue(100);
            checkShift();
          }
        }
      } else {
        qY = rtDW.aacCounter - /*MW:OvSatOk*/ 1U;
        if (qY > rtDW.aacCounter) {
          qY = 0U;
        }

        rtDW.aacCounter = (uint16_T)qY;
        checkShift();
      }
      break;

     case IN_RELEASING:
      if (rtDW.aacCounter <= 1) {
        /* Outport: '<Root>/clutchCurrVal' */
        c_sf_internal_predicateOutput = ((rtDW.aac_dtRelease <= 0) ||
          (rtY.clutchCurrVal <= getAacParam(RAMP_END)));
        if (c_sf_internal_predicateOutput) {
          Clutch_setValue(0);

          /* Outputs for Function Call SubSystem: '<S2>/UnsetRPMLimiter' */
          /* S-Function (Efi_unsetRPMLimiter): '<S17>/Efi UnSetRPMLimiter' */
          Efi_unsetRPMLimiter_Outputs_wrapper(&rtDW.EfiUnSetRPMLimiter);

          /* SignalConversion: '<S17>/OutportBufferFordownCut_pin' */
          rtDW.Merge2 = rtDW.EfiUnSetRPMLimiter;

          /* End of Outputs for SubSystem: '<S2>/UnsetRPMLimiter' */
          rtDW.is_ACTIVE = IN_NO_ACTIVE_CHILD;
          if (rtDW.is_ACTIVE != IN_RUNNING) {
            rtDW.is_ACTIVE = IN_RUNNING;
            rtDW.aacCounter = AAC_WORK_RATE_ms;

            /* Inport: '<Root>/currentGear' */
            rtDW.lastShift = rtU.currentGear;
            aacCheckShift();
          }
        } else {
          rtDW.is_ACTIVE = IN_NO_ACTIVE_CHILD;
          if (rtDW.is_ACTIVE != IN_RELEASING) {
            rtDW.is_ACTIVE = IN_RELEASING;
            rtDW.aac_clutchValue -= rtDW.aac_clutchStep;
            tmp_0 = rt_roundd_snf(rtDW.aac_clutchValue);
            if (tmp_0 < 256.0) {
              if (tmp_0 >= 0.0) {
                tmp_1 = (uint8_T)tmp_0;
              } else {
                tmp_1 = 0U;
              }
            } else {
              tmp_1 = MAX_uint8_T;
            }

            Clutch_setValue(tmp_1);
            if (rtDW.aac_dtRelease < -2147483647) {
              rtDW.aac_dtRelease = MIN_int32_T;
            } else {
              rtDW.aac_dtRelease--;
            }

            rtDW.aacCounter = AAC_WORK_RATE_ms;
          }
        }
      } else {
        qY = rtDW.aacCounter - /*MW:OvSatOk*/ 1U;
        if (qY > rtDW.aacCounter) {
          qY = 0U;
        }

        rtDW.aacCounter = (uint16_T)qY;
      }
      break;

     case IN_RUNNING:
      /* Inport: '<Root>/currentGear' */
      if (rtU.currentGear == 3) {
        rtDW.is_ACTIVE = IN_NO_ACTIVE_CHILD;
        rtDW.is_AAC = IN_NO_ACTIVE_CHILD;
        if (rtDW.is_AAC != IN_STOPPING) {
          rtDW.is_AAC = IN_STOPPING;

          /* Outputs for Function Call SubSystem: '<S2>/UnsetBlip' */
          UnsetBlip(&rtDW.Merge, &rtDW.UnsetBlip_e);

          /* End of Outputs for SubSystem: '<S2>/UnsetBlip' */
        }
      } else {
        aacCheckShift();
      }
      break;

     case IN_START:
      if (rtDW.aacCounter <= 1) {
        rtDW.is_ACTIVE = IN_NO_ACTIVE_CHILD;
        if (rtDW.is_ACTIVE != IN_READY) {
          rtDW.is_ACTIVE = IN_READY;
          rtDW.aacCounter = AAC_WORK_RATE_ms;
          Clutch_setValue(100);
          checkShift();
        }
      } else {
        qY = rtDW.aacCounter - /*MW:OvSatOk*/ 1U;
        if (qY > rtDW.aacCounter) {
          qY = 0U;
        }

        rtDW.aacCounter = (uint16_T)qY;
      }
      break;

     case IN_START_RELEASE:
      if (rtDW.aacCounter <= 1) {
        rtDW.is_ACTIVE = IN_NO_ACTIVE_CHILD;
        if (rtDW.is_ACTIVE != IN_RELEASING) {
          rtDW.is_ACTIVE = IN_RELEASING;
          rtDW.aac_clutchValue -= rtDW.aac_clutchStep;
          tmp_0 = rt_roundd_snf(rtDW.aac_clutchValue);
          if (tmp_0 < 256.0) {
            if (tmp_0 >= 0.0) {
              tmp_1 = (uint8_T)tmp_0;
            } else {
              tmp_1 = 0U;
            }
          } else {
            tmp_1 = MAX_uint8_T;
          }

          Clutch_setValue(tmp_1);
          if (rtDW.aac_dtRelease < -2147483647) {
            rtDW.aac_dtRelease = MIN_int32_T;
          } else {
            rtDW.aac_dtRelease--;
          }

          rtDW.aacCounter = AAC_WORK_RATE_ms;
        }
      } else {
        qY = rtDW.aacCounter - /*MW:OvSatOk*/ 1U;
        if (qY > rtDW.aacCounter) {
          qY = 0U;
        }

        rtDW.aacCounter = (uint16_T)qY;
      }
      break;
    }
  }

  /* End of Inport: '<Root>/aacCom' */
}

/* Function for Chart: '<Root>/GCULogic' */
static void checkClutch(void)
{
  /* Inport: '<Root>/clutchCom' */
  if ((rtU.clutchCom[0] != rtDW.lastClutchCom) && (((!(rtDW.is_GEARSHIFT ==
          IN_DOWNSHIFTING)) && (!(rtDW.is_NEUTRAL_STATE == IN_SET_NEUTRAL))) ||
       (rtDW.is_NEUTRAL_STATE == IN_UNSET_NEUTRAL))) {
    rtDW.lastClutchCom = rtU.clutchCom[0];
    Clutch_setValue(rtU.clutchCom[1]);
  }

  /* End of Inport: '<Root>/clutchCom' */
}

/* Model step function */
void GCU_timer_step(void)
{
  uint32_T qY;

  /* Chart: '<Root>/GCULogic' incorporates:
   *  Inport: '<Root>/aacCom'
   *  Inport: '<Root>/startEngCom'
   *  Outport: '<Root>/Alive'
   */
  rtDW.sfEvent = CALL_EVENT;
  if (rtDW.is_active_c3_GCU_timer == 0U) {
    rtDW.is_active_c3_GCU_timer = 1U;
    rtDW.is_active_MODES = 1U;
    rtDW.lastAacCom = 0U;
    rtDW.lastShiftCom = 0U;
    rtDW.lastClutchCom = 0U;
    rtDW.is_MODES = IN_INIT;
    rtDW.is_active_NEUTRAL_STATE = 1U;
    rtDW.is_NEUTRAL_STATE = IN_NEUTRAL;
    if (rtDW.is_active_GEARSHIFT != 1U) {
      rtDW.is_active_GEARSHIFT = 1U;
    }

    if (rtDW.is_GEARSHIFT != IN_INIT_f) {
      rtDW.is_GEARSHIFT = IN_INIT_f;
      rtDW.ticksCounter = 0;
    }

    rtDW.is_active_START_ENGINE = 1U;
    rtDW.lastCom = 0U;
    rtDW.is_START_ENGINE = IN_WAIT;
  } else {
    if (rtDW.is_active_MODES != 0U) {
      switch (rtDW.is_MODES) {
       case IN_AAC:
        switch (rtDW.is_AAC) {
         case IN_ACTIVE:
          ACTIVE();
          break;

         case IN_STOPPING:
          rtDW.is_AAC = IN_NO_ACTIVE_CHILD;
          rtDW.is_MODES = IN_NO_ACTIVE_CHILD;
          if (rtDW.is_MODES != IN_NORMAL) {
            rtDW.is_MODES = IN_NORMAL;
            qY = rtY.Alive + /*MW:OvSatOk*/ 1U;
            if (qY < rtY.Alive) {
              qY = MAX_uint32_T;
            }

            /* Outport: '<Root>/Alive' */
            rtY.Alive = qY;
            checkShift();
            checkClutch();
          }
          break;
        }
        break;

       case IN_INIT:
        rtDW.is_MODES = IN_NO_ACTIVE_CHILD;
        if (rtDW.is_MODES != IN_NORMAL) {
          rtDW.is_MODES = IN_NORMAL;
          qY = rtY.Alive + /*MW:OvSatOk*/ 1U;
          if (qY < rtY.Alive) {
            qY = MAX_uint32_T;
          }

          /* Outport: '<Root>/Alive' */
          rtY.Alive = qY;
          checkShift();
          checkClutch();
        }
        break;

       case IN_NORMAL:
        if ((rtU.aacCom[0] != rtDW.lastAacCom) && (rtU.aacCom[1] ==
             START_AAC_COM)) {
          rtDW.lastAacCom = rtU.aacCom[0];
          rtDW.is_MODES = IN_AAC;
          rtDW.aac_parameters[0] = 50;
          rtDW.aac_parameters[1] = 0;
          rtDW.aac_parameters[2] = 250;
          rtDW.aac_parameters[3] = 11000;
          rtDW.aac_parameters[4] = 11000;
          rtDW.aac_parameters[5] = 11000;
          rtDW.aac_parameters[6] = 11000;
          rtDW.aac_parameters[7] = 46;
          rtDW.aac_parameters[8] = 61;
          rtDW.aac_parameters[9] = 77;
          rtDW.aac_parameters[10] = 113;
          rtDW.aac_clutchValue = 0.0;
          rtDW.is_AAC = IN_ACTIVE;
          if (rtDW.is_ACTIVE != IN_START) {
            rtDW.is_ACTIVE = IN_START;
            rtDW.aacCounter = AAC_WORK_RATE_ms;

            /* Outputs for Function Call SubSystem: '<S2>/SetRPMLimiter' */
            /* S-Function (Efi_setRPMLimiter): '<S14>/Efi SetRPMLimiter' */
            Efi_setRPMLimiter_Outputs_wrapper(&rtDW.EfiSetRPMLimiter);

            /* SignalConversion: '<S14>/OutportBufferFordownCut_pin' */
            rtDW.Merge2 = rtDW.EfiSetRPMLimiter;

            /* End of Outputs for SubSystem: '<S2>/SetRPMLimiter' */
            Clutch_setValue(100);
          }
        } else {
          qY = rtY.Alive + /*MW:OvSatOk*/ 1U;
          if (qY < rtY.Alive) {
            qY = MAX_uint32_T;
          }

          /* Outport: '<Root>/Alive' */
          rtY.Alive = qY;
          checkShift();
          checkClutch();
        }
        break;
      }
    }

    if (rtDW.is_active_NEUTRAL_STATE != 0U) {
      NEUTRAL_STATE();
    }

    if (rtDW.is_active_GEARSHIFT != 0U) {
      GEARSHIFT();
    }

    if (rtDW.is_active_START_ENGINE != 0U) {
      switch (rtDW.is_START_ENGINE) {
       case IN_START_b:
        if (rtDW.startCounter == 0) {
          rtDW.is_START_ENGINE = IN_NO_ACTIVE_CHILD;
          if (rtDW.is_START_ENGINE != IN_STOP) {
            rtDW.is_START_ENGINE = IN_STOP;

            /* Outputs for Function Call SubSystem: '<S3>/EngineControl_Stop' */
            /* S-Function (EngineControl_stop): '<S19>/EngineControl Stop' */
            EngineControl_stop_Outputs_wrapper(&rtDW.EngineControlStop);

            /* SignalConversion: '<S19>/OutportBufferForengine_starter' */
            rtDW.Merge_e = rtDW.EngineControlStop;

            /* End of Outputs for SubSystem: '<S3>/EngineControl_Stop' */
          }
        } else {
          qY = rtDW.startCounter - /*MW:OvSatOk*/ 1U;
          if (qY > rtDW.startCounter) {
            qY = 0U;
          }

          rtDW.startCounter = (uint8_T)qY;
        }
        break;

       case IN_STOP:
        if (rtU.startEngCom != rtDW.lastCom) {
          rtDW.is_START_ENGINE = IN_NO_ACTIVE_CHILD;
          if (rtDW.is_START_ENGINE != IN_START_b) {
            rtDW.is_START_ENGINE = IN_START_b;

            /* Outputs for Function Call SubSystem: '<S3>/EngineControl_Start' */
            EngineControl_Start(&rtDW.Merge_e, &rtDW.EngineControl_Start_l);

            /* End of Outputs for SubSystem: '<S3>/EngineControl_Start' */
            rtDW.lastCom = rtU.startEngCom;
            rtDW.startCounter = 100U;
          }
        }
        break;

       case IN_WAIT:
        if (rtU.startEngCom != rtDW.lastCom) {
          rtDW.is_START_ENGINE = IN_NO_ACTIVE_CHILD;
          if (rtDW.is_START_ENGINE != IN_START_b) {
            rtDW.is_START_ENGINE = IN_START_b;

            /* Outputs for Function Call SubSystem: '<S3>/EngineControl_Start' */
            EngineControl_Start(&rtDW.Merge_e, &rtDW.EngineControl_Start_l);

            /* End of Outputs for SubSystem: '<S3>/EngineControl_Start' */
            rtDW.lastCom = rtU.startEngCom;
            rtDW.startCounter = 100U;
          }
        }
        break;
      }
    }
  }

  /* End of Chart: '<Root>/GCULogic' */

  /* Outport: '<Root>/upCut_Pin' */
  rtY.upCut_Pin = rtDW.Merge1;

  /* Outport: '<Root>/downCut_Pin' */
  rtY.downCut_Pin = rtDW.Merge;

  /* Outport: '<Root>/rpmLimiter_Pin' */
  rtY.rpmLimiter_Pin = rtDW.Merge2;

  /* Outport: '<Root>/PinIn1' */
  rtY.PinIn1 = rtDW.Pin_In1;

  /* Outport: '<Root>/PinIn2' */
  rtY.PinIn2 = rtDW.Pin_In2;

  /* Outport: '<Root>/PinH' */
  rtY.PinH = rtDW.Pin_H;

  /* Outport: '<Root>/engineStarter_pin' */
  rtY.engineStarter_pin = rtDW.Merge_e;

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  rtM->Timing.t[0] =
    (++rtM->Timing.clockTick0) * rtM->Timing.stepSize0;

  {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.001, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     */
    rtM->Timing.clockTick1++;
  }
}

/* Model initialize function */
void GCU_timer_initialize(void)
{
  /* Registration code */
  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&rtM->solverInfo, &rtM->Timing.simTimeStep);
    rtsiSetTPtr(&rtM->solverInfo, &rtmGetTPtr(rtM));
    rtsiSetStepSizePtr(&rtM->solverInfo, &rtM->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&rtM->solverInfo, ((const char_T **)
      (&rtmGetErrorStatus(rtM))));
    rtsiSetRTModelPtr(&rtM->solverInfo, rtM);
  }

  rtsiSetSimTimeStep(&rtM->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&rtM->solverInfo,"FixedStepDiscrete");
  rtmSetTPtr(rtM, &rtM->Timing.tArray[0]);
  rtM->Timing.stepSize0 = 0.001;

  /* SystemInitialize for Chart: '<Root>/GCULogic' */
  rtDW.sfEvent = CALL_EVENT;
  rtDW.aac_parameters[0] = 50;
  rtDW.aac_parameters[1] = 0;
  rtDW.aac_parameters[2] = 250;
  rtDW.aac_parameters[3] = 11000;
  rtDW.aac_parameters[4] = 11000;
  rtDW.aac_parameters[5] = 11000;
  rtDW.aac_parameters[6] = 11000;
  rtDW.aac_parameters[7] = 46;
  rtDW.aac_parameters[8] = 61;
  rtDW.aac_parameters[9] = 77;
  rtDW.aac_parameters[10] = 113;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
